#include "UtFcallC.h"
#include <stdio.h>
#include <stdlib.h>
SUBROUTINE OSQENV(envname,envvalue,len_1,len_2)
char *envname,*envvalue;
FORTRAN_LEN len_1,len_2;
/*
C.======================================================================
C.    PURPOSE                                                           
C     Get_unix_environment_variable                                 UT<<
C     This routine is unix operating system dependent
C.----------------------------------------------------------------------
C.    KEYWORDS                                                          
C.----------------------------------------------------------------------
C.    INPUT                                                             
C..   envname   - name  of environment variable
C                                                                       
C.    OUTPUT                                                            
C..   envvalue  - value of environment variable
C.----------------------------------------------------------------------
C.    PROGRAMMER    Stein Holger Pettersen
C.    CREATION_DATE 04 Apr 1991
C.    MADE_AT  NTNF/NORSAR                                              
C     Pb. 51                                                            
C     N-2007 Kjeller                                                    
C                                                                       
C.    MODIFICATION                                                      
C.    CORRECTION                                                        
C.======================================================================
*/
{
char *ptr;
  if ((ptr=getenv(envname))!=(char *)0)
     (void)sprintf(envvalue,"%.*s",len_2,ptr);
}

SUBROUTINE OSSENV(envname,envvalue,rc,len_1,len_2)
char *envname,*envvalue;
INTEGER *rc;
FORTRAN_LEN len_1,len_2;
/*
C.======================================================================
C.    PURPOSE                                                           
C     Set_unix_environment_variable                                 UT<<
C     This routine is unix operating system dependent
C.----------------------------------------------------------------------
C.    KEYWORDS                                                          
C.----------------------------------------------------------------------
C.    INPUT                                                             
C..   envname   - name  of environment variable
C..   envvalue  - value of environment variable
C                                                                       
C.    OUTPUT                                                            
C..   rc        - return code
C		  0 = ok	
C.----------------------------------------------------------------------
C.    PROGRAMMER    Stein Holger Pettersen
C.    CREATION_DATE 06 Jan 1997
C.    MADE_AT  NTNF/NORSAR
C     Pb. 51
C     N-2007 Kjeller
C
C.    MODIFICATION
C.    CORRECTION
C.======================================================================
*/
{
char *ptr;
size_t len;
  if (len_1<1) { *rc=1; return; }
  if (len_2<1) { *rc=2; return; }
  len=len_1+len_2+2;
  ptr=(char*)malloc(len);
  if (!ptr) { *rc=-1; return; }
  (void)sprintf(ptr,"%.*s=%.*s",len_1,envname,len_2,envvalue);
/* If only one space then no value ! */
  if (len_2==1&&ptr[len-2]==' ') ptr[len-2]='\0';
  *rc=putenv(ptr);
  if (*rc) perror("OSSENV");
}

/* Fix to enable static linking on ibm */
#ifdef IBM
int pthread_yield()
{
}
#endif
