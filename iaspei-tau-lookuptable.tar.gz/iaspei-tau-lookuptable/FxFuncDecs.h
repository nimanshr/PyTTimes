#if SUN || LINUX
/*
  To enable 64 bit I/O on SUN or Linux (e.g. > 2Gb files)
  you need to define _LARGEFILE64_SOURCE and use fopen64
*/
#define _LARGEFILE64_SOURCE 1
typedef struct stat64	 STAT_STRUCT;
typedef struct statvfs64 STATVFS_STRUCT;
#define Fopen(a1,a2)	fopen64(a1,a2)
#define Stat(a1,a2)	stat64(a1,a2)
#define Statvfs(a1,a2)	statvfs64(a1,a2)
#if SUN && __STDC__ - 0 == 1
#define LONGLONG(a1)	a1._l[0]*2147483648+a1._l[1]
#else
#define LONGLONG(a1)	a1
#endif
#else /* Not SUN or LINUX */
typedef struct stat	STAT_STRUCT;
typedef struct statvfs	STATVFS_STRUCT;
#define Fopen(a1,a2)	fopen(a1,a2)
#define Stat(a1,a2)	stat(a1,a2)
#define Statvfs(a1,a2)	statvfs(a1,a2)
#define LONGLONG(a1)	a1
#endif

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <sys/time.h>
#include <ctype.h>
#include <dirent.h>
#include <grp.h>
#include <pwd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#ifdef __STDC__
extern void ByteSwap2(char *b, unsigned long n);
extern void ByteSwap4(char *b, unsigned long n);
extern void ByteSwap8(char *b, unsigned long n);
#else
extern void ByteSwap2();
extern void ByteSwap4();
extern void ByteSwap8();
#endif

#ifdef ALPHA
#define LittleEndian 1
#endif

#ifndef FALSE
#define FALSE 0
#define TRUE  1
#endif

#ifndef SEEK_SET
#define SEEK_SET 0
#define SEEK_CUR 1
#define SEEK_END 2
#endif

#ifdef _TYPE_GLOBALS
#define _DATA_TYPE
#else
#define _DATA_TYPE      extern
#endif

#define MAX_FX_FILES	256
_DATA_TYPE FILE *fxfiles[MAX_FX_FILES];

#define FxFile(i)		(i<1||i>MAX_FX_FILES) ? 0 : fxfiles[i-1]
#define FILE_EXIST(file)        (access(file,0) ? 0 : 1)

typedef struct _FxFileList {
  char *name;
  char *owner;
  char *group;
  char *lmdate;
  float size;
} FxFileInfo, *FxFileInfoPtr;

typedef FxFileInfoPtr *FxFileInfoList;

extern void FxFreeIndex(int);
extern int FxNewIndex(FILE *);
extern int FxFileLastModDate(char *path,int format,char **last);
extern int FxFileSystemSpace(char *path,float *size,float *free,float *avail);
extern int FxDiskUsage(char *path,float *size);
extern int FxListFiles(char *dir,char *pattern,int filetype,int sortby,
		char **header,char **format,FxFileInfoList *list,int *n);
extern void FxSortFiles(int sortby,FxFileInfoList list,int n);
extern void FxFreeFiles(FxFileInfoList list,int n);

/* Routines called by FORTRAN */
#include "../include/Fortran-C.h"
#if UnderscoreSuffix
#define FXOPEN          fxopen_
#define FXOPN           fxopn_
#define FXCLOS          fxclos_
#define FXCLS           fxcls_
#define FXWRCH          fxwrch_
#define FXWRI2          fxwri2_
#define FXWRI4          fxwri4_
#define FXWRR4          fxwrr4_
#define FXWRR8          fxwrr8_
#define FXRDCH          fxrdch_
#define FXRDI2          fxrdi2_
#define FXRDI4          fxrdi4_
#define FXRDR4          fxrdr4_
#define FXRDR8          fxrdr8_
#define FXREW           fxrew_
#define FXEOF           fxeof_
#define FXSPOS          fxspos_
#define FXQDAT          fxqdat_
#define FXQPOS          fxqpos_
#define FXQSIZ          fxqsiz_
#define FXQSIZE         fxqsize_
#define FXTMPN          fxtmpn_
#define FXRDLN          fxrdln_
#define FXWRLN          fxwrln_
#define FXFLUSH		fxflush_
#define FXSBUF		fxsbuf_
#define FXSUBO		fxsubo_
#define FXSOCL		fxsocl_
#define FXSOCIL		fxsocil_
#define FXSOCRL		fxsocrl_
#define FXSECL		fxsecl_
#define FXSECIL		fxsecil_
#define FXSECRL		fxsecrl_
#define FXQFS		fxqfs_
#define FXQDU		fxqdu_
#define FXQLMD		fxqlmd_
#define FXLIST		fxlist_
#define FXSORT		fxsort_
#else
#define FXOPEN          fxopen
#define FXOPN           fxopn
#define FXCLOS          fxclos
#define FXCLS           fxcls
#define FXWRCH          fxwrch
#define FXWRI2          fxwri2
#define FXWRI4          fxwri4
#define FXWRR4          fxwrr4
#define FXWRR8          fxwrr8
#define FXRDCH          fxrdch
#define FXRDI2          fxrdi2
#define FXRDI4          fxrdi4
#define FXRDR4          fxrdr4
#define FXRDR8          fxrdr8
#define FXREW           fxrew
#define FXEOF           fxeof
#define FXSPOS          fxspos
#define FXQDAT          fxqdat
#define FXQPOS          fxqpos
#define FXQSIZ          fxqsiz
#define FXQSIZE         fxqsize
#define FXTMPN          fxtmpn
#define FXRDLN          fxrdln
#define FXWRLN          fxwrln
#define FXFLUSH		fxflush
#define FXSBUF		fxsbuf
#define FXSUBO		fxsubo
#define FXSOCL		fxsocl
#define FXSOCIL		fxsocil
#define FXSOCRL		fxsocrl
#define FXSECL		fxsecl
#define FXSECIL		fxsecil
#define FXSECRL		fxsecrl
#define FXQFS		fxqfs
#define FXQDU		fxqdu
#define FXQLMD		fxqlmd
#define FXLIST		fxlist
#define FXSORT		fxsort
#endif

#ifdef __STDC__
SUBROUTINE FXOPEN (FORTRAN_CHARACTER *cname, FORTRAN_INTEGER *ilen, FORTRAN_CHARACTER *cmode, FORTRAN_INTEGER*ifptr, FORTRAN_INTEGER *istat, FORTRAN_LEN len_1, FORTRAN_LEN len_2);
SUBROUTINE FXOPN (FORTRAN_CHARACTER *cname, FORTRAN_INTEGER *ilen, FORTRAN_CHARACTER *cmode, FORTRAN_INTEGER*ifptr, FORTRAN_INTEGER *istat, FORTRAN_LEN len_1, FORTRAN_LEN len_2);
SUBROUTINE FXCLOS (FORTRAN_INTEGER *ifptr, FORTRAN_INTEGER *istat);
SUBROUTINE FXCLS (FORTRAN_INTEGER *ifptr, FORTRAN_INTEGER *istat);
SUBROUTINE FMWRCH (FORTRAN_INTEGER *ifptr, FORTRAN_INTEGER *imaxl, FORTRAN_CHARACTER *cbuff, FORTRAN_INTEGER *inbwrt);
SUBROUTINE FMWRI2 (FORTRAN_INTEGER *ifptr, FORTRAN_INTEGER *imaxl, FORTRAN_CHARACTER *iarr, FORTRAN_INTEGER *iniwrt);
SUBROUTINE FMWRI4 (FORTRAN_INTEGER *ifptr, FORTRAN_INTEGER *imaxl, FORTRAN_CHARACTER *iarr, FORTRAN_INTEGER *iniwrt);
SUBROUTINE FMWRR4 (FORTRAN_INTEGER *ifptr, FORTRAN_INTEGER *imaxl, FORTRAN_CHARACTER *rarr, FORTRAN_INTEGER *inrwrt);
SUBROUTINE FMRDCH (FORTRAN_INTEGER *ifptr, FORTRAN_INTEGER *imaxl, FORTRAN_CHARACTER *cbuff, FORTRAN_INTEGER *inbrd);
SUBROUTINE FMRDI2 (FORTRAN_INTEGER *ifptr, FORTRAN_INTEGER *imaxl, FORTRAN_CHARACTER *iarr, FORTRAN_INTEGER *inird);
SUBROUTINE FMRDI4 (FORTRAN_INTEGER *ifptr, FORTRAN_INTEGER *imaxl, FORTRAN_CHARACTER *iarr, FORTRAN_INTEGER *inird);
SUBROUTINE FMRDR4 (FORTRAN_INTEGER *ifptr, FORTRAN_INTEGER *imaxl, FORTRAN_CHARACTER *rarr, FORTRAN_INTEGER *inrrd);
SUBROUTINE FXREW (FORTRAN_INTEGER *ifptr, FORTRAN_INTEGER *istat);
SUBROUTINE FXEOF (FORTRAN_INTEGER *ifptr, FORTRAN_INTEGER *istat);
SUBROUTINE FXSPOS (FORTRAN_INTEGER *ifptr, FORTRAN_INTEGER *ipos, FORTRAN_CHARACTER *cposmd, FORTRAN_INTEGER *istat, FORTRAN_LEN len_1);
SUBROUTINE FXQPOS (FORTRAN_INTEGER *ifptr, FORTRAN_INTEGER *ipos );
SUBROUTINE FXQSIZ (FORTRAN_CHARACTER *cname, FORTRAN_INTEGER *ilen, FORTRAN_INTEGER *isize, FORTRAN_LEN len_1 );
SUBROUTINE FXQSIZE(FORTRAN_CHARACTER *cname, FORTRAN_INTEGER *ilen, FORTRAN_REAL *rsize, FORTRAN_INTEGER *IRC, FORTRAN_LEN len_1 );
SUBROUTINE FXTMPN (FORTRAN_CHARACTER *cdir, FORTRAN_INTEGER *idlen, FORTRAN_CHARACTER *ctmpn, FORTRAN_INTEGER *itlen , FORTRAN_LEN len_1, FORTRAN_LEN len_2);
SUBROUTINE FXQFS(FORTRAN_CHARACTER *CFS, FORTRAN_INTEGER *ILCSF,
 FORTRAN_REAL *RSIZE, FORTRAN_REAL *RFREE, FORTRAN_REAL *RAVAIL, FORTRAN_INTEGER *IRC,
 FORTRAN_LEN len_CFS);
SUBROUTINE FXQDU(FORTRAN_CHARACTER *CN, FORTRAN_INTEGER *ILCN,
 FORTRAN_REAL *RSIZE, FORTRAN_INTEGER *IRC,
 FORTRAN_LEN len_CN);
SUBROUTINE FXQLMD(FORTRAN_CHARACTER *CFS, FORTRAN_INTEGER *ILCSF, FORTRAN_INTEGER *IFORM,
 FORTRAN_CHARACTER *CLMD, FORTRAN_INTEGER *IRC,
 FORTRAN_LEN len_CFS, FORTRAN_LEN len_CLMD);
SUBROUTINE FXLIST(CHARACTER *CDIR, CHARACTER *CPATTERN,
 INTEGER *ITYPE,INTEGER *ISORT, INTEGER *IM,
 CHARACTER *CHEAD, CHARACTER *CLIST, INTEGER *IN, INTEGER *IC, INTEGER *IRC,
 FORTRAN_LEN len_CDIR,FORTRAN_LEN len_CPATTERN,FORTRAN_LEN len_CHEAD,FORTRAN_LEN len_CLIST);
SUBROUTINE FXSORT(INTEGER *IC, INTEGER *ISORT, INTEGER *IM,
 CHARACTER *CHEAD, CHARACTER *CLIST, INTEGER *IN, INTEGER *IRC,
 FORTRAN_LEN len_CHEAD,FORTRAN_LEN len_CLIST);
#else
SUBROUTINE FXOPEN ();
SUBROUTINE FXOPN ();
SUBROUTINE FXCLOS ();
SUBROUTINE FMWRCH ();
SUBROUTINE FMWRI2 ();
SUBROUTINE FMWRI4 ();
SUBROUTINE FMWRR2 ();
SUBROUTINE FMWRR4 ();
SUBROUTINE FMRDCH ();
SUBROUTINE FMRDI2 ();
SUBROUTINE FMRDI4 ();
SUBROUTINE FMRDR2 ();
SUBROUTINE FMRDR4 ();
SUBROUTINE FXREW ();
SUBROUTINE FXEOF ();
SUBROUTINE FXSPOS ();
SUBROUTINE FXQPOS ();
SUBROUTINE FXQSIZ ();
SUBROUTINE FXTMPN ();
SUBROUTINE FXQFS();
SUBROUTINE FXQDU();
SUBROUTINE FXQLMD();
SUBROUTINE FXLIST();
SUBROUTINE FXSORT();
#endif
