C FMAN     FM-I-U   Created: 8/24/89 Copied : 08/25/89 Made at NORSAR
*COPY FMAN
C.======================================================================
C.    PURPOSE
C     File_MANager                                               FM_LL<<
C.----------------------------------------------------------------------
C.    PARAMETER
C
C..   NF1              - array dimensions , that is maximum number
C                        of files to keep in memory
C..   LFNAM            - length of FILNAM
C..   LFORM            - length of FIFMTS
C..   NFILES           - number of files opened
C..   NSPACE           - max number of files
C..   LOWNUM           - lower limit of unit number value
C..   HIGNUM           - upper limit of unit number value
C..   TERMIN           - terminal input unit number
C..   TERMUT           - terminal output unit number
C..   LITTER           - system output unit number
C..   LDLBFN           - length of default litter bug file name
C..   DLBFN(1:LDLBFN)  - default litter bug file name
C..   LLST             - length of opsys command used by FMLIST
C..   LSTCOM(1:LLST)   - opsys command used by FMLIST
C..   LEDT             - length of opsys command used by FMEDIT
C..   EDTCOM(1:LLST)   - opsys command used by FMEDIT
C..   JIED             - index of first charcter in filename when
C                        calling FMEDIT (usually 1, 2 onIBM VM)
C..   JUREC            - number of bytes in each system dependent unit
C                        used on unformatted record files
C..   JVREC            - additional field on variable record
C                        files (in bytes)
C..   MRLSFF           - Max recordlength sequential, formatted  ,
C                        fixed    record files
C..   MRLSFV           - Max recordlength sequential, formatted  ,
C                        variable record files
C..   MRLSUF           - Max recordlength sequential, unformatted,
C                        fixed    record files
C..   MRLSUV           - Max recordlength sequential, unformatted,
C                        variable record files
C..   MRLDF            - Max recordlength direct    , formatted   files
C..   MRLDU            - Max recordlength direct    , unformatted files
C..   IUNIT  (1-*)     - fortran unit number
C..   SFILE  (1-*)     - system file index
C..   UFILE  (1-*)     - user   file index
C..   LRECL  (1-*)     - record length
C..   NREC   (1-*)     - number of records
C..   OPN    (1-*)     - opened/closed status parameter
C..   ACC    (1-*)     - file access parameter
C..   FOV    (1-*)     - fixed or variable length parameter
C..   FMT    (1-*)     - formatted/unformatted parameter
C..   STATUS (1-*)     - status parameter
C..   FILNAM (1-*)     - real file name. Machine dependent format.
C..   FIFMTS (1-*)     - file format string
C.----------------------------------------------------------------------
C.    PROGRAMMER    Rolf Magne Aasen / Stein Holger Pettersen
C.    CREATION_DATE 22 Aug 1985
C.    MADE_AT    NTNF/NORSAR
C     Pb. 51
C     N-2007 Kjeller
C
C.    MODIFICATION
C     25/11/86 by RMAa :
C           A new concept is introduced. That is the 'SYSTEM FILE'.
C           A system file is a unique file in the program system
C           and is adressed with a system file number.
C           The number is a pointer to a complete file definition
C           on a separate file. Alle necessary data except Fortran
C           unit number, is found here.
C           The Fortran unit number used when opening a system file
C           is the first free number returned from the File MANager
C           - FMAN.
C           The system file index will be stored in the array SFILE.
C           An unopened system file  will be marked as 'R'
C           - reserved - in the open/close/reserved parameter OPN.
C     19/06/89 by SHP  :
C           Minor changes. Rearrange order of variables in common
C           Set LFNAM and LFORM as parameters
C     27/06/89 BY SHP  :
C           Added system dependent values ( set in FMISDV)
C
C.    CORRECTION
C.======================================================================
      PARAMETER ( NF1    = 100 )
      PARAMETER ( LFNAM  = 220 )
      PARAMETER ( LFORM  =  40 )
 
      INTEGER  NFILES,NSPACE,LOWNUM,HIGNUM,TERMIN,TERMUT,LITTER,
     +         LDLBFN,LLST,LEDT,JIED,JUREC,JVREC,
     +         MRLSFF,MRLSFV,MRLSUF,MRLSUV,MRLDF,MRLDU,
     +         IUNIT(NF1),SFILE(NF1),UFILE(NF1),LRECL(NF1),NREC(NF1)
 
      CHARACTER*1       OPN(NF1),ACC(NF1),FOV(NF1),FMT(NF1),STATUS(NF1)
      CHARACTER*(LFNAM) FILNAM(NF1),DLBFN
      CHARACTER*20      LSTCOM,EDTCOM
      CHARACTER*(LFORM) FIFMTS(NF1)
 
      COMMON /FMAN/   NFILES,NSPACE,LOWNUM,HIGNUM,TERMIN,TERMUT,LITTER,
     +                LDLBFN,LLST,LEDT,JIED,JUREC,JVREC,
     +                MRLSFF,MRLSFV,MRLSUF,MRLSUV,MRLDF,MRLDU,
     +                IUNIT,SFILE,UFILE,LRECL,NREC,
     +                OPN,ACC,FOV,FMT,STATUS,FILNAM,
     +                DLBFN,LSTCOM,EDTCOM,FIFMTS
