#ifndef _Fortran_C_h
#define _Fortran_C_h

/* Define FORTRAN - C interface */
#if SUN || IBM || ALPHA || HPUX || SGI || LINUX || unix
#define UnderscoreSuffix        1
#define DoubleUnderscore        1  /* Jan for calling fortran from C */
#define UnderscoreSuffixCtoF    1  /* Jan for calling fortran from C */
#define FortranCharLenLastArg	1
#else
#define UnderscoreSuffix        0
#define UnderscoreSuffixCtoF    0  /* Jan for calling fortran from C */
#define DoubleUnderscore        0  /* Jan for calling fortran from C */
#define FortranCharLenLastArg	1
#endif
#if sun
#define UnderscoreSuffix        1
#define DoubleUnderscore        0  /* Jan for calling fortran from C */
#define UnderscoreSuffixCtoF    1  /* Jan for calling fortran from C */
#define FortranCharLenLastArg   1
#endif
#if gnucomp
#define UnderscoreSuffix        1
#define DoubleUnderscore        1  /* Jan for calling fortran from C */
#define UnderscoreSuffixCtoF    1  /* Jan for calling fortran from C */
#define FortranCharLenLastArg   1
#endif

/* C-Fortran variable declaration types */
#define SUBROUTINE	void
#define CALL
typedef char    FORTRAN_CHARACTER;
typedef char    CHARACTER;
typedef int     FORTRAN_INTEGER;
typedef int     INTEGER;
typedef short   FORTRAN_INTEGER2;
typedef short   INTEGER2;
typedef int     FORTRAN_LOGICAL;
typedef int     LOGICAL;
typedef float   FORTRAN_REAL;
typedef float   REAL;
typedef double  FORTRAN_DOUBLE_PRECISION;
typedef double  DOUBLE_PRECISION;
typedef int     FORTRAN_LEN;
/* Keep old form too, for compatibility, remove later */
#define FcallC		void
#define CcallF
typedef int     FORTRAN_CHARLEN_TYPE;

/* Utility functions */
extern char *NewFortranString(
#ifdef __STDC__
	char *, int
#endif
);
extern char *NewFortranStringArrayElement(
#ifdef __STDC__
	int, char *, int
#endif
);
extern char *FortranStringArrayElement(
#ifdef __STDC__
	int, char *, int
#endif
);
extern char *CutFortranString(
);

extern int  FortranStringLength(
#ifdef __STDC__
	char *, int
#endif
);
#endif
