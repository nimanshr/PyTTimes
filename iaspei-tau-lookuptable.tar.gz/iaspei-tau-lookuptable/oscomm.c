#include "UtFcallC.h"
#include <stdio.h>
#include <stdlib.h>
SUBROUTINE OSCOMM(string,irc,dummy)
FORTRAN_CHARACTER *string;
FORTRAN_INTEGER *irc;
FORTRAN_LEN dummy;
/*
C.======================================================================
C.    PURPOSE                                                           
C     Execute_Operating_System_COMMand                              UT<<
C     OSCOMM pass a command string to be used as a system call to Unix
C     The string MUST be zero terminated by the fortran program.
C     Return code  is implementation dependent in C function system
C.----------------------------------------------------------------------
C.    KEYWORDS                                                          
C.----------------------------------------------------------------------
C.    INPUT                                                             
C..   string - command string to be passed to system
C                                                                       
C.    OUTPUT                                                            
C..   IRC    - Return code
C              = 0  no error                                     
C              = ?
C.----------------------------------------------------------------------
C.    PROGRAMMER    Stein Holger Pettersen
C.    CREATION_DATE 09 May 1989
C.    MADE_AT  NTNF/NORSAR                                              
C     Pb. 51                                                            
C     N-2007 Kjeller                                                    
C                                                                       
C.    MODIFICATION                                                      
C.    CORRECTION                                                        
C.======================================================================
*/
{
  *irc = system(string);
  if (*irc<0) perror("system");
}
