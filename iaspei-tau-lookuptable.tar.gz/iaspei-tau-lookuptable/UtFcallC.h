/* Routines called by FORTRAN */
/* Define FORTRAN - C interface */
#include "./Fortran-C.h"
/* Machine dependent Fortran C interface */
#if UnderscoreSuffix
#define FMGLST		fmglst_
#define FMGNUM		fmgnum_
#define FMFACC		fmfacc_
#define OSCOMM		oscomm_
#define OSQENV		osqenv_
#define OSSENV		ossenv_
#define OSLTIM		osltim_
#define OSWAIT		oswait_
#define IUSHFT		iushft_
#define IUAND		iuand_
#define IUOR		iuor_
#define IUNOT		iunot_
#define ISHFT		ishft_
#define IAND		iand_
#define IOR		ior_
#define OSINFO		osinfo_
#else
#define FMGLST		fmglst
#define FMGNUM		fmgnum
#define FMFACC		fmfacc
#define OSCOMM		oscomm
#define OSQENV		osqenv
#define OSSENV		ossenv
#define OSLTIM		osltim
#define OSWAIT		oswait
#define IUSHFT		iushft
#define IUAND		iuand
#define IUOR		iuor
#define IUNOT		iunot
#define ISHFT		ishft
#define IAND		iand
#define IOR		ior
#define OSINFO		osinfo
#endif
